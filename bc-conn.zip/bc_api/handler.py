import requests

class BCHandler:
    """Handler for BC API operations."""
    
    def __init__(self, tenant_id: str, env_name: str, company_name: str, token: str):
        
        self.base_url = "https://api.businesscentral.dynamics.com/v2.0/"
        self.tenant_id = tenant_id
        self.env_name = env_name
        self.company_name = company_name
        self.token = token
        self.headers = {'Authorization': f'Bearer {self.token}'}

    def get_data(self, table_name: str):
        """
        Retrieve data from a specified table in Business Central.
        
        Args:
            table_name: Name of the table to retrieve data from
            
        Returns:
            dict: Data retrieved from the specified table
            
        Raises:
            ValueError: If table name is invalid
            Exception: For other errors during data retrieval
        """
        if not table_name:
            raise ValueError("Table name is required")
        
        endpoint = f"{self.base_url}{self.tenant_id}/{self.env_name}/ODataV4/Company('{self.company_name}')/{table_name}"
        
        try:
            response = requests.get(endpoint, headers=self.headers, verify=False)  # Consider using proper SSL certificates in production
            response.raise_for_status()  # Raise exception for HTTP errors
            
            return response.json()
            
        except requests.exceptions.HTTPError as e:
            raise Exception(f"Failed to retrieve data from {table_name}: {e.response.status_code} - {e.response.text}")
        
        except Exception as e:
            raise Exception(f"An error occurred while retrieving data: {str(e)}")